import Image from "next/image"
import { MapPin, Clock, Phone } from "lucide-react"

export default function VisitPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="bg-[#1a1a2e] text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Visit Us</h1>
          <p className="text-xl max-w-3xl mx-auto">Find us at the iconic Volksparkstadion, home of Hamburger SV</p>
        </div>
      </section>

      {/* Location & Hours */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="section-title text-[#1a1a2e]">Location & Hours</h2>

              <div className="space-y-6 mt-8">
                <div className="flex items-start">
                  <MapPin className="w-6 h-6 text-[#0066b2] mr-4 mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="font-bold text-lg text-[#1a1a2e]">Address</h3>
                    <p className="text-gray-700">
                      Stadion Steakhaus SV
                      <br />
                      Volksparkstadion
                      <br />
                      Sylvesterallee 7<br />
                      22525 Hamburg, Germany
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <Clock className="w-6 h-6 text-[#0066b2] mr-4 mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="font-bold text-lg text-[#1a1a2e]">Opening Hours</h3>
                    <div className="grid grid-cols-2 gap-2 text-gray-700">
                      <div>Monday - Thursday:</div>
                      <div>11:00 - 22:00</div>
                      <div>Friday - Saturday:</div>
                      <div>11:00 - 23:00</div>
                      <div>Sunday:</div>
                      <div>12:00 - 21:00</div>
                      <div className="col-span-2 mt-2 font-medium">
                        * Extended hours on match days (open until 2 hours after the final whistle)
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-start">
                  <Phone className="w-6 h-6 text-[#0066b2] mr-4 mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="font-bold text-lg text-[#1a1a2e]">Contact</h3>
                    <p className="text-gray-700">
                      Phone: +49 (0) 40 1234 5678
                      <br />
                      Email: info@stadionsteakhaus.de
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-8">
                <h3 className="font-bold text-lg text-[#1a1a2e] mb-4">Reservations</h3>
                <p className="text-gray-700 mb-4">
                  Reservations are recommended, especially on match days and weekends. Please call us or use our online
                  reservation system to secure your table.
                </p>
                <button className="bg-[#0066b2] hover:bg-blue-800 text-white px-6 py-3 rounded-md transition-colors">
                  Make a Reservation
                </button>
              </div>
            </div>

            <div className="relative h-[400px] md:h-[500px] rounded-lg overflow-hidden shadow-xl">
              <Image
                src="/placeholder.svg?height=800&width=800"
                alt="Map of Volksparkstadion"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Getting Here */}
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-4">
          <h2 className="section-title text-[#1a1a2e] mx-auto text-center">Getting Here</h2>
          <div className="max-w-4xl mx-auto mt-12">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="font-bold text-lg text-[#1a1a2e] mb-4">By Public Transport</h3>
                <ul className="space-y-3 text-gray-700">
                  <li className="flex items-start">
                    <span className="font-bold mr-2">S-Bahn:</span>
                    <span>Take the S3 or S5 to Stellingen station, then a 10-minute walk to the stadium.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="font-bold mr-2">Bus:</span>
                    <span>Lines 22, 180, and 280 stop directly at the stadium (Volksparkstadion stop).</span>
                  </li>
                </ul>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="font-bold text-lg text-[#1a1a2e] mb-4">By Car</h3>
                <ul className="space-y-3 text-gray-700">
                  <li className="flex items-start">
                    <span className="font-bold mr-2">From A7:</span>
                    <span>Take exit 26-HH-Stellingen toward B4/B5/Stellingen/Volkspark.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="font-bold mr-2">Parking:</span>
                    <span>Ample parking is available at the stadium. Parking fee applies.</span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="mt-8 bg-white p-6 rounded-lg shadow-md">
              <h3 className="font-bold text-lg text-[#1a1a2e] mb-4">Stadium Access</h3>
              <p className="text-gray-700 mb-4">
                Stadion Steakhaus SV is located in the west stand of Volksparkstadion. Enter through Gate W3 and follow
                signs to the restaurant. On non-match days, you can also enter through the main stadium entrance.
              </p>
              <p className="text-gray-700">
                <span className="font-bold">Note:</span> On match days, a valid match ticket or restaurant reservation
                is required to access the stadium area.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Special Events */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="section-title text-[#1a1a2e] mx-auto text-center">Special Events</h2>
          <p className="text-center text-gray-700 max-w-3xl mx-auto mt-4 mb-12">
            Stadion Steakhaus SV is the perfect venue for your special occasions
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="bg-gray-50 p-6 rounded-lg shadow-md">
              <h3 className="font-bold text-lg text-[#1a1a2e] mb-3">Private Dining</h3>
              <p className="text-gray-700 mb-4">
                Our private dining area can accommodate groups of up to 20 people, perfect for family celebrations or
                corporate events.
              </p>
              <a href="#" className="text-[#0066b2] font-medium hover:underline">
                Learn more
              </a>
            </div>

            <div className="bg-gray-50 p-6 rounded-lg shadow-md">
              <h3 className="font-bold text-lg text-[#1a1a2e] mb-3">Match Day Packages</h3>
              <p className="text-gray-700 mb-4">
                Combine a premium dining experience with HSV match tickets for an unforgettable day at Volksparkstadion.
              </p>
              <a href="#" className="text-[#0066b2] font-medium hover:underline">
                Learn more
              </a>
            </div>

            <div className="bg-gray-50 p-6 rounded-lg shadow-md">
              <h3 className="font-bold text-lg text-[#1a1a2e] mb-3">Corporate Events</h3>
              <p className="text-gray-700 mb-4">
                Host your next business meeting or team event in our unique stadium setting with catering options.
              </p>
              <a href="#" className="text-[#0066b2] font-medium hover:underline">
                Learn more
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
