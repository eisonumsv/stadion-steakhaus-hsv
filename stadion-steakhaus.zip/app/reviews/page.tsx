import Image from "next/image"
import { Star } from "lucide-react"

export default function ReviewsPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="bg-[#1a1a2e] text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Reviews</h1>
          <p className="text-xl max-w-3xl mx-auto">See what our guests have to say about their experiences</p>
        </div>
      </section>

      {/* Reviews Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Review 1 */}
            <div className="bg-gray-50 p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <div className="flex mr-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-[#0066b2] text-[#0066b2]" />
                  ))}
                </div>
                <span className="text-gray-600">5.0</span>
              </div>
              <p className="text-gray-700 mb-4">
                "The steaks at Stadion Steakhaus SV are absolutely incredible. Perfectly cooked and seasoned. The
                atmosphere on match days is electric - there's nothing like enjoying a premium meal while overlooking
                the pitch. Will definitely be back!"
              </p>
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-gray-300 mr-3"></div>
                <div>
                  <h4 className="font-bold text-[#1a1a2e]">Michael Schmidt</h4>
                  <p className="text-sm text-gray-600">Hamburg</p>
                </div>
              </div>
            </div>

            {/* Review 2 */}
            <div className="bg-gray-50 p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <div className="flex mr-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-[#0066b2] text-[#0066b2]" />
                  ))}
                </div>
                <span className="text-gray-600">5.0</span>
              </div>
              <p className="text-gray-700 mb-4">
                "I visited the café for a business meeting and was impressed by both the quality of the coffee and the
                attentive service. The pastries are freshly made and delicious. The view of the stadium adds a unique
                touch to the experience."
              </p>
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-gray-300 mr-3"></div>
                <div>
                  <h4 className="font-bold text-[#1a1a2e]">Laura Müller</h4>
                  <p className="text-sm text-gray-600">Berlin</p>
                </div>
              </div>
            </div>

            {/* Review 3 */}
            <div className="bg-gray-50 p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <div className="flex mr-2">
                  {[...Array(4)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-[#0066b2] text-[#0066b2]" />
                  ))}
                  <Star className="w-5 h-5 text-gray-300" />
                </div>
                <span className="text-gray-600">4.0</span>
              </div>
              <p className="text-gray-700 mb-4">
                "We celebrated my father's birthday at Stadion Steakhaus and had a wonderful time. The T-bone steak was
                exceptional, and the staff went above and beyond to make our celebration special. Only minor issue was
                the wait time, but it was a busy match day."
              </p>
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-gray-300 mr-3"></div>
                <div>
                  <h4 className="font-bold text-[#1a1a2e]">Thomas Weber</h4>
                  <p className="text-sm text-gray-600">Hamburg</p>
                </div>
              </div>
            </div>

            {/* Review 4 - Matchday Experience */}
            <div className="bg-gray-50 p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <div className="flex mr-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-[#0066b2] text-[#0066b2]" />
                  ))}
                </div>
                <span className="text-gray-600">5.0</span>
              </div>
              <p className="text-gray-700 mb-4">
                "As a regular at HSV matches, I've made Stadion Steakhaus my pre-game tradition. The matchday menu is
                excellent value, and there's nothing like watching the stadium fill up while enjoying a great meal. The
                staff remembers regular customers, which is a nice touch."
              </p>
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-gray-300 mr-3"></div>
                <div>
                  <h4 className="font-bold text-[#1a1a2e]">Jan Hoffmann</h4>
                  <p className="text-sm text-gray-600">Hamburg</p>
                </div>
              </div>
            </div>

            {/* Review 5 */}
            <div className="bg-gray-50 p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <div className="flex mr-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-[#0066b2] text-[#0066b2]" />
                  ))}
                </div>
                <span className="text-gray-600">5.0</span>
              </div>
              <p className="text-gray-700 mb-4">
                "I visited the café for a morning meeting and was blown away by the quality of their coffee and
                pastries. The view of the empty stadium is surprisingly peaceful. The staff was knowledgeable and
                friendly. Will definitely return!"
              </p>
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-gray-300 mr-3"></div>
                <div>
                  <h4 className="font-bold text-[#1a1a2e]">Sophie Klein</h4>
                  <p className="text-sm text-gray-600">Munich</p>
                </div>
              </div>
            </div>

            {/* Review 6 - Family Matchday Experience */}
            <div className="bg-gray-50 p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <div className="flex mr-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-[#0066b2] text-[#0066b2]" />
                  ))}
                </div>
                <span className="text-gray-600">5.0</span>
              </div>
              <p className="text-gray-700 mb-4">
                "We took our kids to Stadion Steakhaus before an HSV match and had an amazing family experience. The
                children's menu was perfect, and they loved watching the players warm up while we ate. The family
                package is excellent value and the staff were so accommodating with the kids."
              </p>
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-gray-300 mr-3"></div>
                <div>
                  <h4 className="font-bold text-[#1a1a2e]">Markus Fischer</h4>
                  <p className="text-sm text-gray-600">Hamburg</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Matchday Experience Highlight */}
      <section className="py-16 bg-[#0066b2] text-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-center">Matchday Experiences</h2>
          <div className="w-20 h-1 bg-white mx-auto mb-12"></div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <div className="relative h-64 md:h-80 rounded-lg overflow-hidden">
              <Image src="/images/restaurant-2.png" alt="Family Dining on Match Day" fill className="object-cover" />
              <div className="absolute inset-0 bg-black bg-opacity-40 flex items-end p-6">
                <div>
                  <h3 className="text-xl font-bold mb-2">Family Dining</h3>
                  <p className="text-white/90">
                    "The perfect place to bring the family before the match. The kids loved watching the stadium fill
                    up!"
                  </p>
                </div>
              </div>
            </div>

            <div className="relative h-64 md:h-80 rounded-lg overflow-hidden">
              <Image src="/images/restaurant-3.png" alt="Premium Matchday Experience" fill className="object-cover" />
              <div className="absolute inset-0 bg-black bg-opacity-40 flex items-end p-6">
                <div>
                  <h3 className="text-xl font-bold mb-2">Premium Experience</h3>
                  <p className="text-white/90">
                    "There's nothing like enjoying a premium steak while overlooking the pitch before an HSV match!"
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonial Highlight */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-[#1a1a2e]">What Our Guests Love</h2>
          <div className="w-20 h-1 bg-[#0066b2] mx-auto mb-12"></div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="p-6 rounded-lg bg-gray-50 shadow-md">
              <h3 className="text-xl font-bold mb-3 text-[#1a1a2e]">Premium Steaks</h3>
              <p className="text-gray-700">
                "The best steak I've had in Hamburg. Perfectly aged and cooked exactly to my preference."
              </p>
            </div>

            <div className="p-6 rounded-lg bg-gray-50 shadow-md">
              <h3 className="text-xl font-bold mb-3 text-[#1a1a2e]">Matchday Experience</h3>
              <p className="text-gray-700">
                "There's nothing like enjoying a great meal while watching the stadium come alive before a match."
              </p>
            </div>

            <div className="p-6 rounded-lg bg-gray-50 shadow-md">
              <h3 className="text-xl font-bold mb-3 text-[#1a1a2e]">Exceptional Service</h3>
              <p className="text-gray-700">
                "The staff goes above and beyond to make every visit special. They remember returning guests!"
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Leave a Review */}
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6 text-[#1a1a2e]">Share Your Experience</h2>
            <p className="text-gray-700 mb-8">
              We value your feedback! Let us know about your visit to Stadion Steakhaus SV.
            </p>
            <button className="bg-[#0066b2] hover:bg-blue-800 text-white px-6 py-3 rounded-md transition-colors">
              Write a Review
            </button>
          </div>
        </div>
      </section>
    </div>
  )
}
