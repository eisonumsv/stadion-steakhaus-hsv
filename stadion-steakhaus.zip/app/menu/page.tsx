import Image from "next/image"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function MenuPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[40vh] flex items-center justify-center">
        <div
          className="absolute inset-0 z-0"
          style={{
            backgroundImage:
              "url('https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-807Hac5RthaiuUcAtIXdUvzCjLsMbj.png')",
            backgroundSize: "cover",
            backgroundPosition: "center",
            filter: "brightness(0.5)",
          }}
        />
        <div className="container mx-auto px-4 z-10 text-center text-white">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Our Menu</h1>
          <p className="text-xl max-w-3xl mx-auto">
            Discover our premium steaks, café offerings, and matchday specials
          </p>
        </div>
      </section>

      {/* Menu Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <Tabs defaultValue="steakhouse" className="w-full max-w-4xl mx-auto">
            <TabsList className="grid w-full grid-cols-2 mb-12">
              <TabsTrigger value="steakhouse" className="text-lg py-3">
                Steakhouse
              </TabsTrigger>
              <TabsTrigger value="cafe" className="text-lg py-3">
                Café
              </TabsTrigger>
            </TabsList>

            {/* Steakhouse Menu */}
            <TabsContent value="steakhouse">
              <div className="space-y-12">
                {/* Starters */}
                <div>
                  <h2 className="text-2xl font-bold mb-6 text-[#1a1a2e] border-b-2 border-[#0066b2] pb-2">Starters</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="flex gap-4">
                      <div className="w-20 h-20 relative rounded-md overflow-hidden flex-shrink-0">
                        <Image
                          src="/placeholder.svg?height=200&width=200"
                          alt="German Pretzel"
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-[#1a1a2e]">Bavarian Pretzel</h3>
                        <p className="text-gray-600 mb-2">Traditional German pretzel served with beer cheese dip</p>
                        <p className="font-medium">€8.50</p>
                      </div>
                    </div>

                    <div className="flex gap-4">
                      <div className="w-20 h-20 relative rounded-md overflow-hidden flex-shrink-0">
                        <Image
                          src="/placeholder.svg?height=200&width=200"
                          alt="Beef Carpaccio"
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-[#1a1a2e]">Beef Carpaccio</h3>
                        <p className="text-gray-600 mb-2">Thinly sliced raw beef with capers, arugula and parmesan</p>
                        <p className="font-medium">€14.00</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Premium Steaks */}
                <div>
                  <h2 className="text-2xl font-bold mb-6 text-[#1a1a2e] border-b-2 border-[#0066b2] pb-2">
                    Premium Steaks
                  </h2>
                  <p className="text-gray-700 mb-6 italic">
                    All steaks are served with your choice of two sides and a sauce
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="flex gap-4">
                      <div className="w-20 h-20 relative rounded-md overflow-hidden flex-shrink-0">
                        <Image src="/images/steak-1.png" alt="Ribeye Steak" fill className="object-cover" />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-[#1a1a2e]">Ribeye Steak</h3>
                        <p className="text-gray-600 mb-2">
                          12oz prime ribeye, perfectly marbled and grilled to your preference
                        </p>
                        <p className="font-medium">€32.00</p>
                      </div>
                    </div>

                    <div className="flex gap-4">
                      <div className="w-20 h-20 relative rounded-md overflow-hidden flex-shrink-0">
                        <Image src="/images/steak-2.png" alt="Filet Mignon" fill className="object-cover" />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-[#1a1a2e]">Filet Mignon</h3>
                        <p className="text-gray-600 mb-2">8oz center-cut filet, the most tender steak available</p>
                        <p className="font-medium">€36.00</p>
                      </div>
                    </div>

                    <div className="flex gap-4">
                      <div className="w-20 h-20 relative rounded-md overflow-hidden flex-shrink-0">
                        <Image src="/images/steak-3.png" alt="T-Bone Steak" fill className="object-cover" />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-[#1a1a2e]">T-Bone Steak</h3>
                        <p className="text-gray-600 mb-2">20oz steak featuring both the strip and tenderloin</p>
                        <p className="font-medium">€42.00</p>
                      </div>
                    </div>

                    <div className="flex gap-4">
                      <div className="w-20 h-20 relative rounded-md overflow-hidden flex-shrink-0">
                        <Image src="/images/steak-4.png" alt="Tomahawk Steak" fill className="object-cover" />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-[#1a1a2e]">Tomahawk Steak</h3>
                        <p className="text-gray-600 mb-2">32oz bone-in ribeye, perfect for sharing</p>
                        <p className="font-medium">€65.00</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* German Specialties */}
                <div>
                  <h2 className="text-2xl font-bold mb-6 text-[#1a1a2e] border-b-2 border-[#0066b2] pb-2">
                    German Specialties
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="flex gap-4">
                      <div className="w-20 h-20 relative rounded-md overflow-hidden flex-shrink-0">
                        <Image src="/images/schnitzel.png" alt="Wiener Schnitzel" fill className="object-cover" />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-[#1a1a2e]">Wiener Schnitzel</h3>
                        <p className="text-gray-600 mb-2">
                          Traditional breaded veal cutlet served with roasted potatoes and lingonberry sauce
                        </p>
                        <p className="font-medium">€24.00</p>
                      </div>
                    </div>

                    <div className="flex gap-4">
                      <div className="w-20 h-20 relative rounded-md overflow-hidden flex-shrink-0">
                        <Image
                          src="/placeholder.svg?height=200&width=200"
                          alt="Sauerbraten"
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-[#1a1a2e]">Sauerbraten</h3>
                        <p className="text-gray-600 mb-2">Marinated pot roast with red cabbage and potato dumplings</p>
                        <p className="font-medium">€26.00</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Sides */}
                <div>
                  <h2 className="text-2xl font-bold mb-6 text-[#1a1a2e] border-b-2 border-[#0066b2] pb-2">Sides</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="p-4 border rounded-md">
                      <h3 className="font-bold text-[#1a1a2e]">Truffle Mashed Potatoes</h3>
                      <p className="text-gray-600">€6.00</p>
                    </div>
                    <div className="p-4 border rounded-md">
                      <h3 className="font-bold text-[#1a1a2e]">Grilled Asparagus</h3>
                      <p className="text-gray-600">€5.50</p>
                    </div>
                    <div className="p-4 border rounded-md">
                      <h3 className="font-bold text-[#1a1a2e]">Creamed Spinach</h3>
                      <p className="text-gray-600">€5.50</p>
                    </div>
                    <div className="p-4 border rounded-md">
                      <h3 className="font-bold text-[#1a1a2e]">Sautéed Mushrooms</h3>
                      <p className="text-gray-600">€6.00</p>
                    </div>
                    <div className="p-4 border rounded-md">
                      <h3 className="font-bold text-[#1a1a2e]">Hand-Cut Fries</h3>
                      <p className="text-gray-600">€5.00</p>
                    </div>
                    <div className="p-4 border rounded-md">
                      <h3 className="font-bold text-[#1a1a2e]">German Potato Salad</h3>
                      <p className="text-gray-600">€5.50</p>
                    </div>
                  </div>
                </div>

                {/* Desserts */}
                <div>
                  <h2 className="text-2xl font-bold mb-6 text-[#1a1a2e] border-b-2 border-[#0066b2] pb-2">Desserts</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="flex gap-4">
                      <div className="w-20 h-20 relative rounded-md overflow-hidden flex-shrink-0">
                        <Image
                          src="/placeholder.svg?height=200&width=200"
                          alt="Black Forest Cake"
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-[#1a1a2e]">Black Forest Cake</h3>
                        <p className="text-gray-600 mb-2">Traditional German chocolate cake with cherries</p>
                        <p className="font-medium">€8.50</p>
                      </div>
                    </div>

                    <div className="flex gap-4">
                      <div className="w-20 h-20 relative rounded-md overflow-hidden flex-shrink-0">
                        <Image
                          src="/placeholder.svg?height=200&width=200"
                          alt="Apple Strudel"
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-[#1a1a2e]">Apple Strudel</h3>
                        <p className="text-gray-600 mb-2">Warm apple strudel with vanilla ice cream</p>
                        <p className="font-medium">€7.50</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Café Menu */}
            <TabsContent value="cafe">
              <div className="space-y-12">
                {/* Coffee & Tea */}
                <div>
                  <h2 className="text-2xl font-bold mb-6 text-[#1a1a2e] border-b-2 border-[#0066b2] pb-2">
                    Coffee & Tea
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="flex gap-4">
                      <div className="w-20 h-20 relative rounded-md overflow-hidden flex-shrink-0">
                        <Image src="/images/coffee.png" alt="Espresso" fill className="object-cover" />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-[#1a1a2e]">Espresso</h3>
                        <p className="text-gray-600 mb-2">Single or double shot of our premium blend</p>
                        <p className="font-medium">€2.50 / €3.50</p>
                      </div>
                    </div>

                    <div className="flex gap-4">
                      <div className="w-20 h-20 relative rounded-md overflow-hidden flex-shrink-0">
                        <Image src="/images/coffee.png" alt="Cappuccino" fill className="object-cover" />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-[#1a1a2e]">Cappuccino</h3>
                        <p className="text-gray-600 mb-2">Espresso with steamed milk and foam</p>
                        <p className="font-medium">€4.00</p>
                      </div>
                    </div>

                    <div className="flex gap-4">
                      <div className="w-20 h-20 relative rounded-md overflow-hidden flex-shrink-0">
                        <Image src="/images/coffee.png" alt="Latte" fill className="object-cover" />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-[#1a1a2e]">Latte</h3>
                        <p className="text-gray-600 mb-2">Espresso with steamed milk</p>
                        <p className="font-medium">€4.50</p>
                      </div>
                    </div>

                    <div className="flex gap-4">
                      <div className="w-20 h-20 relative rounded-md overflow-hidden flex-shrink-0">
                        <Image
                          src="/placeholder.svg?height=200&width=200"
                          alt="Herbal Tea"
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-[#1a1a2e]">Herbal Tea Selection</h3>
                        <p className="text-gray-600 mb-2">Various premium teas</p>
                        <p className="font-medium">€3.50</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Pastries */}
                <div>
                  <h2 className="text-2xl font-bold mb-6 text-[#1a1a2e] border-b-2 border-[#0066b2] pb-2">Pastries</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="flex gap-4">
                      <div className="w-20 h-20 relative rounded-md overflow-hidden flex-shrink-0">
                        <Image
                          src="/placeholder.svg?height=200&width=200"
                          alt="Croissant"
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-[#1a1a2e]">Butter Croissant</h3>
                        <p className="text-gray-600 mb-2">Freshly baked daily</p>
                        <p className="font-medium">€3.00</p>
                      </div>
                    </div>

                    <div className="flex gap-4">
                      <div className="w-20 h-20 relative rounded-md overflow-hidden flex-shrink-0">
                        <Image
                          src="/placeholder.svg?height=200&width=200"
                          alt="Cinnamon Roll"
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-[#1a1a2e]">Cinnamon Roll</h3>
                        <p className="text-gray-600 mb-2">With cream cheese frosting</p>
                        <p className="font-medium">€4.00</p>
                      </div>
                    </div>

                    <div className="flex gap-4">
                      <div className="w-20 h-20 relative rounded-md overflow-hidden flex-shrink-0">
                        <Image
                          src="/placeholder.svg?height=200&width=200"
                          alt="Apple Turnover"
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-[#1a1a2e]">Apple Turnover</h3>
                        <p className="text-gray-600 mb-2">Flaky pastry with spiced apple filling</p>
                        <p className="font-medium">€3.50</p>
                      </div>
                    </div>

                    <div className="flex gap-4">
                      <div className="w-20 h-20 relative rounded-md overflow-hidden flex-shrink-0">
                        <Image
                          src="/placeholder.svg?height=200&width=200"
                          alt="Chocolate Muffin"
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-[#1a1a2e]">Chocolate Muffin</h3>
                        <p className="text-gray-600 mb-2">Rich chocolate with chocolate chips</p>
                        <p className="font-medium">€3.50</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Light Meals */}
                <div>
                  <h2 className="text-2xl font-bold mb-6 text-[#1a1a2e] border-b-2 border-[#0066b2] pb-2">
                    Light Meals
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="flex gap-4">
                      <div className="w-20 h-20 relative rounded-md overflow-hidden flex-shrink-0">
                        <Image
                          src="/placeholder.svg?height=200&width=200"
                          alt="Avocado Toast"
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-[#1a1a2e]">Avocado Toast</h3>
                        <p className="text-gray-600 mb-2">Sourdough bread with smashed avocado and poached egg</p>
                        <p className="font-medium">€9.50</p>
                      </div>
                    </div>

                    <div className="flex gap-4">
                      <div className="w-20 h-20 relative rounded-md overflow-hidden flex-shrink-0">
                        <Image
                          src="/placeholder.svg?height=200&width=200"
                          alt="Chicken Sandwich"
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-[#1a1a2e]">Grilled Chicken Sandwich</h3>
                        <p className="text-gray-600 mb-2">With avocado, bacon, and aioli on ciabatta</p>
                        <p className="font-medium">€12.00</p>
                      </div>
                    </div>

                    <div className="flex gap-4">
                      <div className="w-20 h-20 relative rounded-md overflow-hidden flex-shrink-0">
                        <Image
                          src="/placeholder.svg?height=200&width=200"
                          alt="Caesar Salad"
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-[#1a1a2e]">Caesar Salad</h3>
                        <p className="text-gray-600 mb-2">Romaine lettuce, croutons, parmesan, and Caesar dressing</p>
                        <p className="font-medium">€10.00</p>
                      </div>
                    </div>

                    <div className="flex gap-4">
                      <div className="w-20 h-20 relative rounded-md overflow-hidden flex-shrink-0">
                        <Image src="/placeholder.svg?height=200&width=200" alt="Quiche" fill className="object-cover" />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-[#1a1a2e]">Quiche of the Day</h3>
                        <p className="text-gray-600 mb-2">Served with a side salad</p>
                        <p className="font-medium">€11.00</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Matchday Specials */}
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-6 text-center text-[#1a1a2e]">Matchday Specials</h2>
          <div className="w-20 h-1 bg-[#0066b2] mx-auto mb-12"></div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-48 relative">
                <Image src="/images/steak-3.png" alt="Pre-Match Menu" fill className="object-cover" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2 text-[#1a1a2e]">Pre-Match Menu</h3>
                <p className="text-gray-700 mb-4">
                  A selection of quick bites and drinks perfect for before the match.
                </p>
                <p className="font-medium text-[#0066b2]">From €15.00 per person</p>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-48 relative">
                <Image src="/images/steak-4.png" alt="Victory Platter" fill className="object-cover" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2 text-[#1a1a2e]">Victory Platter</h3>
                <p className="text-gray-700 mb-4">Celebrate a win with our special sharing platter for 4 people.</p>
                <p className="font-medium text-[#0066b2]">€60.00</p>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-48 relative">
                <Image src="/images/schnitzel.png" alt="Family Package" fill className="object-cover" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2 text-[#1a1a2e]">Family Package</h3>
                <p className="text-gray-700 mb-4">Special menu for families with children on matchdays.</p>
                <p className="font-medium text-[#0066b2]">€45.00 for 2 adults and 2 children</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
