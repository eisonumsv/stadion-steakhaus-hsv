import Image from "next/image"

export default function GalleryPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="bg-[#1a1a2e] text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Gallery</h1>
          <p className="text-xl max-w-3xl mx-auto">Explore our dishes, interiors, and stadium views</p>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Gallery Item 1 */}
            <div className="overflow-hidden rounded-lg shadow-md">
              <div className="relative h-64 md:h-80">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-807Hac5RthaiuUcAtIXdUvzCjLsMbj.png"
                  alt="Restaurant Interior"
                  fill
                  className="object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-4 bg-white">
                <h3 className="font-bold text-[#1a1a2e]">Restaurant Interior</h3>
                <p className="text-gray-600 text-sm">Our elegant dining area with stadium views</p>
              </div>
            </div>

            {/* Gallery Item 2 */}
            <div className="overflow-hidden rounded-lg shadow-md">
              <div className="relative h-64 md:h-80">
                <Image
                  src="/images/steak-1.png"
                  alt="Premium Steak"
                  fill
                  className="object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-4 bg-white">
                <h3 className="font-bold text-[#1a1a2e]">Premium Ribeye</h3>
                <p className="text-gray-600 text-sm">Our signature steak, perfectly cooked</p>
              </div>
            </div>

            {/* Gallery Item 3 */}
            <div className="overflow-hidden rounded-lg shadow-md">
              <div className="relative h-64 md:h-80">
                <Image
                  src="/images/restaurant-3.png"
                  alt="Stadium View"
                  fill
                  className="object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-4 bg-white">
                <h3 className="font-bold text-[#1a1a2e]">Volksparkstadion View</h3>
                <p className="text-gray-600 text-sm">The breathtaking view from our dining area</p>
              </div>
            </div>

            {/* Gallery Item 4 */}
            <div className="overflow-hidden rounded-lg shadow-md">
              <div className="relative h-64 md:h-80">
                <Image
                  src="/images/coffee.png"
                  alt="Café Area"
                  fill
                  className="object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-4 bg-white">
                <h3 className="font-bold text-[#1a1a2e]">Café Corner</h3>
                <p className="text-gray-600 text-sm">Our cozy café area for casual dining</p>
              </div>
            </div>

            {/* Gallery Item 5 */}
            <div className="overflow-hidden rounded-lg shadow-md">
              <div className="relative h-64 md:h-80">
                <Image
                  src="/images/steak-2.png"
                  alt="Premium Cut"
                  fill
                  className="object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-4 bg-white">
                <h3 className="font-bold text-[#1a1a2e]">Premium Cuts</h3>
                <p className="text-gray-600 text-sm">Our perfectly cooked medium-rare steaks</p>
              </div>
            </div>

            {/* Gallery Item 6 - Matchday Experience */}
            <div className="overflow-hidden rounded-lg shadow-md">
              <div className="relative h-64 md:h-80">
                <Image
                  src="/images/restaurant-2.png"
                  alt="Match Day Atmosphere"
                  fill
                  className="object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-4 bg-white">
                <h3 className="font-bold text-[#1a1a2e]">Match Day Atmosphere</h3>
                <p className="text-gray-600 text-sm">Families enjoying meals with stadium views on match days</p>
              </div>
            </div>

            {/* Gallery Item 7 */}
            <div className="overflow-hidden rounded-lg shadow-md">
              <div className="relative h-64 md:h-80">
                <Image
                  src="/images/schnitzel.png"
                  alt="German Schnitzel"
                  fill
                  className="object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-4 bg-white">
                <h3 className="font-bold text-[#1a1a2e]">German Schnitzel</h3>
                <p className="text-gray-600 text-sm">Traditional German schnitzel with roasted potatoes</p>
              </div>
            </div>

            {/* Gallery Item 8 */}
            <div className="overflow-hidden rounded-lg shadow-md">
              <div className="relative h-64 md:h-80">
                <Image
                  src="/images/steak-4.png"
                  alt="Chef's Special"
                  fill
                  className="object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-4 bg-white">
                <h3 className="font-bold text-[#1a1a2e]">Chef's Special</h3>
                <p className="text-gray-600 text-sm">Our premium bone-in steak with herbs and potatoes</p>
              </div>
            </div>

            {/* Gallery Item 9 - Private Events */}
            <div className="overflow-hidden rounded-lg shadow-md">
              <div className="relative h-64 md:h-80">
                <Image
                  src="/images/restaurant-1.png"
                  alt="Private Dining"
                  fill
                  className="object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-4 bg-white">
                <h3 className="font-bold text-[#1a1a2e]">Private Events</h3>
                <p className="text-gray-600 text-sm">Our exclusive space for special events with stadium views</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
