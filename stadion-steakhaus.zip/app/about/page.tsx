import Image from "next/image"

export default function AboutPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="bg-[#1a1a2e] text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">About Us</h1>
          <p className="text-xl max-w-3xl mx-auto">
            The story behind Stadion Steakhaus SV and our passion for great food and football
          </p>
        </div>
      </section>

      {/* Owner's Welcome */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="order-2 md:order-1">
              <h2 className="section-title text-[#1a1a2e]">Owner's Welcome</h2>
              <p className="text-lg text-gray-700 mb-6">
                Welcome to Stadion Steakhaus SV! I'm Isaac John Marcial, the proud owner of this unique dining
                establishment.
              </p>
              <p className="text-lg text-gray-700 mb-6">
                My journey began with two passions: exceptional food and Hamburger SV football. After years in the
                culinary industry, I had the opportunity to combine these passions by opening Stadion Steakhaus SV
                within the iconic Volksparkstadion.
              </p>
              <p className="text-lg text-gray-700 mb-6">
                Our mission is simple: to provide an unforgettable dining experience that celebrates the rich tradition
                of German cuisine alongside the sporting heritage of HSV. Whether you're joining us for a pre-match
                meal, a business lunch, or a special celebration, we're committed to excellence in every aspect of your
                visit.
              </p>
              <p className="text-lg text-gray-700 font-semibold">
                I look forward to welcoming you personally to our restaurant!
              </p>
            </div>
            <div className="order-1 md:order-2 flex justify-center">
              <div className="relative w-full max-w-md h-[500px] rounded-lg overflow-hidden shadow-xl">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-fvrMr91LM9UGDYCBJVzQ7I6m3VdoP8.png"
                  alt="Isaac John Marcial - Owner"
                  fill
                  className="object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Team */}
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-4">
          <h2 className="section-title text-[#1a1a2e] text-center mx-auto">Our Team</h2>
          <p className="text-lg text-gray-700 text-center max-w-3xl mx-auto mb-12">
            Meet the dedicated professionals who make Stadion Steakhaus SV an exceptional dining destination
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Team Member 1 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-64 relative">
                <Image src="/placeholder.svg?height=400&width=400" alt="Head Chef" fill className="object-cover" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-1 text-[#1a1a2e]">Marcus Weber</h3>
                <p className="text-[#0066b2] font-medium mb-4">Head Chef</p>
                <p className="text-gray-700">
                  With over 15 years of experience in premium steakhouses across Germany, Marcus brings unparalleled
                  expertise to our kitchen.
                </p>
              </div>
            </div>

            {/* Team Member 2 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-64 relative">
                <Image src="/placeholder.svg?height=400&width=400" alt="Café Manager" fill className="object-cover" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-1 text-[#1a1a2e]">Sophia Müller</h3>
                <p className="text-[#0066b2] font-medium mb-4">Café Manager</p>
                <p className="text-gray-700">
                  A certified barista with a passion for creating the perfect coffee experience for every guest.
                </p>
              </div>
            </div>

            {/* Team Member 3 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-64 relative">
                <Image
                  src="/placeholder.svg?height=400&width=400"
                  alt="Restaurant Manager"
                  fill
                  className="object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-1 text-[#1a1a2e]">Thomas Becker</h3>
                <p className="text-[#0066b2] font-medium mb-4">Restaurant Manager</p>
                <p className="text-gray-700">
                  A lifelong HSV fan with extensive hospitality experience, ensuring your visit is perfect from start to
                  finish.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <h2 className="section-title text-[#1a1a2e] mx-auto text-center">Our Story</h2>
            <div className="space-y-6 text-lg text-gray-700">
              <p>
                Stadion Steakhaus SV was founded in 2018 with a vision to create a dining destination that celebrates
                the rich culinary traditions of Hamburg alongside the sporting heritage of Hamburger SV.
              </p>
              <p>
                Located within the iconic Volksparkstadion, our restaurant offers a unique opportunity to enjoy premium
                dining with views of one of Germany's most historic football grounds.
              </p>
              <p>
                We began as a small matchday café and quickly expanded to include our premium steakhouse, becoming a
                favorite destination for both football fans and food enthusiasts alike.
              </p>
              <p>
                Our commitment to quality ingredients, expert preparation, and exceptional service has established us as
                one of Hamburg's premier dining destinations, whether on match days or any day of the week.
              </p>
              <p>
                As we continue to grow, we remain dedicated to our founding principles: celebrating great food, honoring
                the tradition of HSV, and creating memorable experiences for every guest who walks through our doors.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Staff Message */}
      <section className="py-16 bg-[#0066b2] text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Our Promise To You</h2>
          <div className="w-20 h-1 bg-white mx-auto mb-8"></div>
          <p className="text-xl max-w-3xl mx-auto mb-8">
            "We are committed to providing an exceptional dining experience that honors both the culinary traditions of
            Hamburg and the sporting heritage of HSV. Every dish we serve and every service we provide is delivered with
            passion, expertise, and a dedication to excellence."
          </p>
          <p className="font-bold text-lg">- The Stadion Steakhaus SV Team</p>
        </div>
      </section>
    </div>
  )
}
