import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="hero-section h-[80vh] flex items-center justify-center text-white relative">
        <div
          className="absolute inset-0 z-0 bg-cover bg-center"
          style={{
            backgroundImage:
              "url('https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-807Hac5RthaiuUcAtIXdUvzCjLsMbj.png')",
            filter: "brightness(0.5)",
          }}
        />
        <div className="container mx-auto px-4 z-10 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">Stadion Steakhaus SV</h1>
          <p className="text-xl md:text-2xl mb-8 max-w-2xl mx-auto">
            Premium dining with a view of Volksparkstadion, home of Hamburger SV
          </p>
          <Button asChild className="bg-[#0066b2] hover:bg-blue-800 text-white px-8 py-6 text-lg rounded-md">
            <Link href="/menu">
              Explore Our Menu <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </Button>
        </div>
      </section>

      {/* Introduction Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-[#1a1a2e]">A Culinary Experience Like No Other</h2>
            <div className="w-20 h-1 bg-[#0066b2] mx-auto mb-8"></div>
            <p className="text-lg text-gray-700 mb-8">
              Located in the iconic Volksparkstadion, Stadion Steakhaus SV offers an unforgettable dining experience
              combining premium steaks and delicious café offerings with the passion of Hamburger SV football club.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
              <div className="p-6 border border-gray-200 rounded-lg">
                <h3 className="text-xl font-bold mb-3 text-[#1a1a2e]">Premium Steaks</h3>
                <p className="text-gray-700">
                  Enjoy the finest cuts of meat prepared to perfection by our expert chefs.
                </p>
              </div>
              <div className="p-6 border border-gray-200 rounded-lg">
                <h3 className="text-xl font-bold mb-3 text-[#1a1a2e]">Café Delights</h3>
                <p className="text-gray-700">
                  Savor our selection of coffees, pastries, and light meals in a relaxed atmosphere.
                </p>
              </div>
              <div className="p-6 border border-gray-200 rounded-lg">
                <h3 className="text-xl font-bold mb-3 text-[#1a1a2e]">Stadium Views</h3>
                <p className="text-gray-700">
                  Dine with breathtaking views of the Volksparkstadion, home of Hamburger SV.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Menu Section */}
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-center text-[#1a1a2e]">Featured Menu Items</h2>
          <div className="w-20 h-1 bg-[#0066b2] mx-auto mb-12"></div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Featured Item 1 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-48 relative">
                <Image src="/images/steak-1.png" alt="Premium Ribeye Steak" fill className="object-cover" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2 text-[#1a1a2e]">Premium Ribeye Steak</h3>
                <p className="text-gray-700 mb-4">
                  Our signature 12oz ribeye, perfectly aged and grilled to your preference.
                </p>
                <Link href="/menu" className="text-[#0066b2] font-medium hover:underline inline-flex items-center">
                  View Details <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </div>
            </div>

            {/* Featured Item 2 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-48 relative">
                <Image src="/images/coffee.png" alt="Artisan Coffee Selection" fill className="object-cover" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2 text-[#1a1a2e]">Artisan Coffee Selection</h3>
                <p className="text-gray-700 mb-4">
                  Expertly crafted coffees using premium beans from around the world.
                </p>
                <Link href="/menu" className="text-[#0066b2] font-medium hover:underline inline-flex items-center">
                  View Details <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </div>
            </div>

            {/* Featured Item 3 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-48 relative">
                <Image src="/images/schnitzel.png" alt="German Schnitzel" fill className="object-cover" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2 text-[#1a1a2e]">German Schnitzel</h3>
                <p className="text-gray-700 mb-4">
                  Traditional breaded veal cutlet served with roasted potatoes and lingonberry sauce.
                </p>
                <Link href="/menu" className="text-[#0066b2] font-medium hover:underline inline-flex items-center">
                  View Details <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </div>
            </div>
          </div>

          <div className="text-center mt-12">
            <Button asChild className="bg-[#0066b2] hover:bg-blue-800 text-white px-6 py-3 rounded-md">
              <Link href="/menu">
                View Full Menu <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
