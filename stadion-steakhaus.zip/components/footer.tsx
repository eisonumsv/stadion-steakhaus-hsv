"use client"

import Link from "next/link"
import { Facebook, Instagram, Twitter } from "lucide-react"
import { useState, useEffect } from "react"

export default function Footer() {
  const [germanTime, setGermanTime] = useState("")
  const [localTime, setLocalTime] = useState("")

  useEffect(() => {
    const updateTimes = () => {
      // German time (Central European Time)
      const germanOptions = {
        timeZone: "Europe/Berlin",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: false,
      }
      setGermanTime(new Date().toLocaleTimeString("de-DE", germanOptions))

      // Local time based on user's browser
      const localOptions = {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: false,
      }
      setLocalTime(new Date().toLocaleTimeString(undefined, localOptions))
    }

    updateTimes()
    const interval = setInterval(updateTimes, 1000)

    return () => clearInterval(interval)
  }, [])

  return (
    <footer className="bg-[#1a1a2e] text-white pt-10 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">Stadion Steakhaus SV</h3>
            <p className="mb-2">Premium dining experience at Volksparkstadion</p>
            <div className="flex space-x-4 mt-4">
              <a href="#" className="text-white hover:text-[#0066b2] transition-colors">
                <Facebook />
              </a>
              <a href="#" className="text-white hover:text-[#0066b2] transition-colors">
                <Instagram />
              </a>
              <a href="#" className="text-white hover:text-[#0066b2] transition-colors">
                <Twitter />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="hover:text-[#0066b2] transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/menu" className="hover:text-[#0066b2] transition-colors">
                  Menu
                </Link>
              </li>
              <li>
                <Link href="/visit" className="hover:text-[#0066b2] transition-colors">
                  Visit Us
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-[#0066b2] transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-4">Newsletter</h3>
            <p className="mb-4">Subscribe for updates and special offers</p>
            <div className="flex">
              <input
                type="email"
                placeholder="Your email"
                className="px-4 py-2 w-full text-gray-900 rounded-l focus:outline-none"
              />
              <button className="bg-[#0066b2] px-4 py-2 rounded-r hover:bg-blue-800 transition-colors">
                Subscribe
              </button>
            </div>
            <div className="mt-6 text-sm">
              <div className="flex justify-between">
                <div>
                  Germany: <span className="font-mono">{germanTime}</span>
                </div>
                <div>
                  Local: <span className="font-mono">{localTime}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-6 text-sm text-center">
          <p>&copy; {new Date().getFullYear()} Stadion Steakhaus SV. All rights reserved.</p>
          <div className="mt-2 space-x-4">
            <Link href="/privacy" className="hover:text-[#0066b2] transition-colors">
              Privacy Policy
            </Link>
            <Link href="/terms" className="hover:text-[#0066b2] transition-colors">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
