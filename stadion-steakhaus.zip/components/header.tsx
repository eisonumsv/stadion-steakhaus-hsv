"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X } from "lucide-react"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  return (
    <header className="bg-[#1a1a2e] text-white sticky top-0 z-50 shadow-md">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <Link href="/" className="flex items-center space-x-2">
            <div className="font-bold text-xl md:text-2xl text-white">
              Stadion Steakhaus <span className="text-[#0066b2]">SV</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <Link href="/" className="hover:text-[#0066b2] transition-colors">
              Home
            </Link>
            <Link href="/about" className="hover:text-[#0066b2] transition-colors">
              About Us
            </Link>
            <Link href="/menu" className="hover:text-[#0066b2] transition-colors">
              Menu
            </Link>
            <Link href="/gallery" className="hover:text-[#0066b2] transition-colors">
              Gallery
            </Link>
            <Link href="/reviews" className="hover:text-[#0066b2] transition-colors">
              Reviews
            </Link>
            <Link href="/visit" className="hover:text-[#0066b2] transition-colors">
              Visit Us
            </Link>
            <Link href="/contact" className="hover:text-[#0066b2] transition-colors">
              Contact
            </Link>
          </nav>

          {/* Mobile Menu Button */}
          <button className="md:hidden text-white" onClick={toggleMenu} aria-label="Toggle menu">
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden pt-4 pb-2 space-y-3">
            <Link href="/" className="block py-2 hover:text-[#0066b2] transition-colors" onClick={toggleMenu}>
              Home
            </Link>
            <Link href="/about" className="block py-2 hover:text-[#0066b2] transition-colors" onClick={toggleMenu}>
              About Us
            </Link>
            <Link href="/menu" className="block py-2 hover:text-[#0066b2] transition-colors" onClick={toggleMenu}>
              Menu
            </Link>
            <Link href="/gallery" className="block py-2 hover:text-[#0066b2] transition-colors" onClick={toggleMenu}>
              Gallery
            </Link>
            <Link href="/reviews" className="block py-2 hover:text-[#0066b2] transition-colors" onClick={toggleMenu}>
              Reviews
            </Link>
            <Link href="/visit" className="block py-2 hover:text-[#0066b2] transition-colors" onClick={toggleMenu}>
              Visit Us
            </Link>
            <Link href="/contact" className="block py-2 hover:text-[#0066b2] transition-colors" onClick={toggleMenu}>
              Contact
            </Link>
          </nav>
        )}
      </div>
    </header>
  )
}
